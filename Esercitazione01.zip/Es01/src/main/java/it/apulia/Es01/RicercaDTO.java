package it.apulia.Es01;

import lombok.Data;

@Data
public class RicercaDTO {

    String titolo;

}
